# MOBILADOR PRO X — protótipo Android

Este projeto é um starter em Kotlin + Jetpack Compose.

## Fazer o APK usando apenas o celular (GitHub Actions)
1. Entre em https://github.com pelo navegador e crie uma conta, se ainda não tiver.
2. Crie um repositório novo. Pode deixar como privado.
3. Envie os arquivos e pastas deste projeto para o repositório, mantendo a estrutura (inclua a pasta `.github/workflows`).
4. Abra a aba **Actions** do repositório. Se o GitHub pedir, habilite workflows.
5. Selecione **Build Android APK** e toque em **Run workflow**. (Um push na branch `main` também inicia o build.)
6. Quando terminar com sucesso, abra a execução e baixe o artifact **MobiladorProX-debug-apk**. Extraia o artifact ZIP para obter `app-debug.apk`.
7. Toque no APK para instalar. Talvez o Android peça autorização para instalar apps dessa origem.

O build na nuvem pode levar alguns minutos. O workflow usa Gradle 8.9 e Java 17.

## O que o protótipo inclui
- Cadastro de nomes de jogos (Free Fire e Free Fire MAX pré-cadastrados).
- Sliders para sensibilidade/DPI de referência e botão de salvar perfil (demonstração).
- Tela conceitual de controles.
- Consulta à RAM disponível e dicas básicas.
- Dicas para treino manual de puxada.

## Limitações
- Os valores de sensi não são aplicados automaticamente dentro do Free Fire; ajuste-os no próprio jogo.
- Não promete limpar toda a RAM nem otimizar o aparelho inteiro.
- O mapeador de teclas é apenas uma tela demonstrativa; mapeamento real depende de APIs, permissões e compatibilidade do aparelho/jogo.
- Não inclui mira automática, injeção, ou controle automático de recuo.
