package com.mobilador.prox

import android.app.ActivityManager
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MobiladorScreen(this) }
    }
}

@Composable
fun MobiladorScreen(context: Context) {
    var game by remember { mutableStateOf("Free Fire") }
    var customGame by remember { mutableStateOf("") }
    var games by remember { mutableStateOf(listOf("Free Fire", "Free Fire MAX")) }
    var general by remember { mutableFloatStateOf(90f) }
    var redDot by remember { mutableFloatStateOf(85f) }
    var scope2 by remember { mutableFloatStateOf(75f) }
    var scope4 by remember { mutableFloatStateOf(65f) }
    var dpi by remember { mutableFloatStateOf(450f) }
    var status by remember { mutableStateOf("Pronto para configurar") }

    MaterialTheme {
        Scaffold { padding ->
            Column(Modifier.padding(padding).padding(18.dp).verticalScroll(rememberScrollState())) {
                Text("MOBILADOR PRO X", style = MaterialTheme.typography.headlineMedium)
                Text("Mapeador • Sensi • Desempenho", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(16.dp))
                Text("Jogo selecionado", style = MaterialTheme.typography.titleMedium)
                games.forEach { item ->
                    Row {
                        RadioButton(selected = game == item, onClick = { game = item })
                        Text(item, Modifier.padding(top = 12.dp))
                    }
                }
                OutlinedTextField(value = customGame, onValueChange = { customGame = it },
                    label = { Text("Adicionar outro jogo") }, modifier = Modifier.fillMaxWidth())
                Button(onClick = {
                    val name = customGame.trim()
                    if (name.isNotEmpty() && name !in games) games = games + name
                    if (name.isNotEmpty()) game = name
                    customGame = ""
                }) { Text("Adicionar jogo") }

                HorizontalDivider(Modifier.padding(vertical = 14.dp))
                Text("Ajustador de sensibilidade", style = MaterialTheme.typography.titleLarge)
                Text("Valores sugeridos para testar no próprio jogo; não alteram a sensi automaticamente.")
                SensiSlider("Geral", general) { general = it }
                SensiSlider("Ponto vermelho", redDot) { redDot = it }
                SensiSlider("Mira 2x", scope2) { scope2 = it }
                SensiSlider("Mira 4x", scope4) { scope4 = it }
                SensiSlider("DPI (referência)", dpi, 100f, 800f) { dpi = it }
                Button(onClick = { status = "Perfil salvo localmente para $game (protótipo)." }) {
                    Text("Salvar perfil")
                }
                Text(status)

                HorizontalDivider(Modifier.padding(vertical = 14.dp))
                Text("Mapeador de controles", style = MaterialTheme.typography.titleLarge)
                Text("Protótipo visual: planeje teclas para teclado/mouse. O mapeamento real depende de suporte do Android, acessibilidade e compatibilidade do jogo.")
                Text("WASD: movimento  •  Espaço: pular  •  Mouse: mirar  •  F: interagir")

                HorizontalDivider(Modifier.padding(vertical = 14.dp))
                Text("Desempenho Android", style = MaterialTheme.typography.titleLarge)
                Text("O Android administra a RAM. Este botão consulta a memória disponível; não força encerramento de outros apps nem promete aumentar FPS.")
                Button(onClick = {
                    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                    val info = ActivityManager.MemoryInfo()
                    am.getMemoryInfo(info)
                    val freeMb = info.availMem / (1024 * 1024)
                    status = "RAM disponível no sistema: ${freeMb} MB. Feche apps que você não usa e ative o modo jogo do aparelho."
                }) { Text("Verificar RAM disponível") }

                HorizontalDivider(Modifier.padding(vertical = 14.dp))
                Text("Treino de puxada / recuo", style = MaterialTheme.typography.titleLarge)
                Text("Treine arrastar a mira para cima em um campo de prática. O app não injeta comandos no Free Fire, não mira automaticamente e não modifica arquivos do jogo.")
                Button(onClick = { status = "Dica: teste uma sensibilidade por vez no campo de treinamento e ajuste em pequenos passos." }) {
                    Text("Dica de treino")
                }
                Spacer(Modifier.height(20.dp))
                Text("MOBILADOR PRO X • versão inicial demonstrativa")
            }
        }
    }
}

@Composable
fun SensiSlider(label: String, value: Float, min: Float = 0f, max: Float = 100f, onValue: (Float) -> Unit) {
    Column {
        Text("$label: ${value.toInt()}")
        Slider(value = value, onValueChange = onValue, valueRange = min..max)
    }
}
